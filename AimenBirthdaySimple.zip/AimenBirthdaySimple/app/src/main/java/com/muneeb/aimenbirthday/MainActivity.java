package com.muneeb.aimenbirthday;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button viewButton = findViewById(R.id.btnView);
        final Button againButton = findViewById(R.id.btnAgain);
        final View wishCard = findViewById(R.id.wishCard);

        viewButton.setOnClickListener(v -> {
            viewButton.setVisibility(View.GONE);
            wishCard.setVisibility(View.VISIBLE);
            againButton.setVisibility(View.VISIBLE);
            fadeIn(wishCard);
        });

        againButton.setOnClickListener(v -> fadeIn(wishCard));
    }

    private void fadeIn(View view) {
        view.setAlpha(0f);
        view.animate().alpha(1f).setDuration(900).start();
    }
}
