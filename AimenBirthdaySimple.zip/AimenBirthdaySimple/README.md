# Aimen Birthday Surprise
Simple Java + XML Android app. Push to GitHub; the Actions workflow builds the debug APK
and uploads it as the artifact `Aimen-Birthday-Debug-APK` (app/build/outputs/apk/debug/app-debug.apk).
